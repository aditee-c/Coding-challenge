package testRemote;

import io.bankbridge.handler.BanksRemoteCalls;
import org.json.simple.parser.ParseException;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import spark.Request;
import spark.Response;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.*;

import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.powermock.api.mockito.PowerMockito.whenNew;

@RunWith(MockitoJUnitRunner.class)
public class TestRemoteTest {

    @InjectMocks
    public BanksRemoteCalls banksRemoteCalls;

    @Mock
    Map config;


    @Test
    public void testHandle() throws Exception {


        Set<String> keys = new HashSet<>();

        config.put("xyz","http://localhost:1234/bes");
        keys.add("http://localhost:1234/bes");
        String key = keys.stream().findFirst().get();
        Whitebox.setInternalState(BanksRemoteCalls.class,"config",config);

        Mockito.when(config.keySet()).thenReturn(keys);
        Mockito.when(config.get(key)).thenReturn(key);
        URL url =  MockURL.URL(location);
        HttpURLConnection connection = Mockito.mock(HttpURLConnection.class);


        Mockito.when(url.openConnection()).thenReturn(connection);
        Mockito.when(connection.getInputStream()).thenReturn(null);
        //BanksRemoteCalls banksRemoteCalls = new BanksRemoteCalls();
        banksRemoteCalls.handle(null,null);
    }
}