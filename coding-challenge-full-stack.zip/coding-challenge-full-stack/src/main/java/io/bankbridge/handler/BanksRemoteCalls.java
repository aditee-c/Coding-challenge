package io.bankbridge.handler;
import java.io.*;
import java.net.HttpURLConnection;

import java.net.URL;
import java.util.*;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import spark.Request;
import spark.Response;



public class BanksRemoteCalls {

	private static Map config;

	public static void init() throws Exception {
		config = new ObjectMapper()
				.readValue(Thread.currentThread().getContextClassLoader().getResource("banks-v2.json"), Map.class);

	}

	public  String handle(Request request, Response response) throws IOException, ParseException {
		System.out.println(config);

		List<Map> result = new ArrayList<>();
		// Create Set to store all the url from config
		Set<String> keys = config.keySet();
		//Iterate over the Keys
		for (String key : keys) {

			// Create an object to hold the URL
			URL url = new URL(config.get(key).toString());

			// Open a connection on the URL and cast the response
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();

			// Now it's "open", we can set the request method, headers etc.
			connection.setRequestProperty("accept", "application/json");

			// This line makes the request
			InputStream responseStream = connection.getInputStream();

			// Storing the json response body from the InputStream
			ObjectMapper mapper = new ObjectMapper();
			Map<String, Object> jsonMap = mapper.readValue(responseStream, Map.class);
//			jsonMap.entrySet().forEach(entry -> {
//				System.out.println(entry.getKey() + " " + entry.getValue());
//			});
			result.add(jsonMap);
		}
		String resultAsString = new ObjectMapper().writeValueAsString(result);
		return resultAsString;
	}}
