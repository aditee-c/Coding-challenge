package io.bankbridge.model;
import java.util.List;

public class BankModelList {
	
	public List<BankModel> banks; 

}
